# stringmatching

1. Please make sure you change the path for the CVS file to point where you stored your csv file.

2. Please make sure you change the path for the output file to point where you want to output file. 
