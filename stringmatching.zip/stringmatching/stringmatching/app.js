var stringMatchingPercent = "Jack matches Jill";
let strConcat = '';

function generateNumberStr(str) {

    let generateNumberString = " ";
    str = str.toLowerCase().replace(/\s+/g, '');

    let stringLength = str.length;
    let alreadyCountedCharacter = [];
    let alreadyCountedCharacterIndex = 0;

    for (let i = 0; i < str.length; i++) {
        let ch = str[i];
        if (!alreadyCountedCharacter.includes(ch)) {
            generateNumberString = generateNumberString + str.split('').filter(x => x == ch).length;

            alreadyCountedCharacter.push(ch);
       }
    }

    return generateNumberString;
}

let numberstr = generateNumberStr(stringMatchingPercent);
console.log(numberstr);

function sumFirstPlusLast(str) {

    str = str.toLowerCase().replace(/\s+/g, '');
    let strSum = 0;

    if (str.length >= 2 || strConcat.length > 2) {
        strSum = Number(str[0]) + Number(str[str.length - 1]);
        strConcat = strConcat + strSum.toString();
    }
    return strSum;
}


function calculateMatchingPercentage(str)
{    
    str = str.toLowerCase().replace(/\s+/g, '');
    if (str.length < 1)
    {
        return strConcat;
    }
    else if (str.length === 1)
    {
        strConcat = strConcat + str.toString();
        return strConcat;
    }
    else
    {
        sumFirstPlusLast(str);

        str = str.slice(1);
        str = str.slice(0, str.length - 1);
        calculateMatchingPercentage(str);
    }
    return strConcat;
}


let stringMatchingPercentage = "";
function calculateMatchingPercentagePart2(str)
{
    
    stringMatchingPercentage = calculateMatchingPercentage(str); 
    let len = stringMatchingPercentage.length;
    
    if (len > 2) {
        stringMatchingPercentage = stringMatchingPercentage.toLowerCase().replace(/\s+/g, '');
        strConcat = "";
        calculateMatchingPercentagePart2(stringMatchingPercentage);
    }

    strConcat = "";
    return stringMatchingPercentage;

}

let numstr = generateNumberStr(stringMatchingPercent);
let stringMatchingPercentagePart2 = calculateMatchingPercentagePart2(numstr);

if (stringMatchingPercentagePart2 <= "80") {
    console.log(stringMatchingPercent + " " + stringMatchingPercentagePart2 + "%");
} else {
    console.log(stringMatchingPercent + " " + stringMatchingPercentagePart2 + "%,good match");
}

// (A) FILE SYSTEM MODULE
const fs = require("fs");

// (B) READ CSV INTO STRING
var data = fs.readFileSync("C:\\Users\\pc\\Documents\\workspace\\stringmatch\\stringmatch.csv", "utf8");

// (C) STRING TO ARRAY
data = data.split("\r\n"); // SPLIT ROWS

var males = [];
var females = [];

var matchingStringsObj = {};
var finalMatchingStringsObj = {};

var malesObj = {};
var femalesObj = {};

let x = 0;
let y = 0;


//Remove space in the strings inside the array
data = data.map(function (el) {
    return el.trim();
});

//Remove duplaces in the array
data = data.filter((c, index) => {
    return data.indexOf(c) === index;
});

let removedLast2 = "";
for (let i in data)
{
    //Get the last character in a string
    let last = data[i].charAt(data[i].length - 1);    
    
    if (last === "m") {

        //Remove last two characters in a string
        removedLast2 = data[i].slice(0, -2);

        //Add modified string to a new male array
        males.push(removedLast2.trim());
        males = males.filter(item => item);      
        
        x++;
    }
    else if (last === "f")
    {
        //Remove last two characters in a string
        removedLast2 = data[i].slice(0, -2);

        //Add modified string to a new female array
        females.push(removedLast2.trim());
        females = females.filter(item => item);          

        y++;
    }

    
}


matchArrayStrings(males, females);

var myKey = "";
function matchArrayStrings(arr1, arr2) {    

    for (let y in arr1) {
        for (let x in arr2) {

            myKey = arr1[y]  + " matches " + arr2[x];
            
            if (calculateMatchingPercentagePart2(generateNumberStr(myKey)) <= "80") {
                matchingStringsObj[myKey] = calculateMatchingPercentagePart2(generateNumberStr(myKey));
            }
            else {
                matchingStringsObj[myKey] = calculateMatchingPercentagePart2(generateNumberStr(myKey));
            }       
                  
        }
    }   
    matchingStringsObj = sortedObjects(matchingStringsObj);
   
    return matchingStringsObj;
}

function sortedObjects(myObject)
{   
    myObject = Object.entries(myObject)
        .sort(([, b], [, a]) => a - b)
        .reduce((r, [k, v]) => ({ ...r, [k]: v }), {});

    return myObject;
}

function convertStringsToObjects(myObject)
{
    let stringifiedObj = Object.entries(myObject).map(x => x.join(":")).join("\n")
    return stringifiedObj;
}

var arrayTest = [];
var numbering = 0;
for (const key in matchingStringsObj) {

    if (matchingStringsObj[key] <= "80") {
        finalMatchingStringsObj["" + numbering + ""] = key + " " + matchingStringsObj[key] + "%";
        arrayTest.push(key + " " + matchingStringsObj[key] + "%");
    } else {
        finalMatchingStringsObj["" + numbering +""] = key + " " + matchingStringsObj[key] + "%,good match\n";
        arrayTest.push(key + " " + matchingStringsObj[key] + "%,good match\n");
    } 

    numbering++;
}

var stringifiedObj = convertStringsToObjects(finalMatchingStringsObj);

fs.writeFile('C:\\Users\\pc\\Documents\\workspace\\stringmatch\\output.txt', "Output \n\n" + stringifiedObj, err => {
    if (err) {
        console.error(err)
        console.log("Error: "+ err);
        return
    }
    console.log("file written successfully");
    //file written successfully
})